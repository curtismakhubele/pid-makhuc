#!/bin/sh
export HOST="${HOST:-0.0.0.0}"
python -u server.py
