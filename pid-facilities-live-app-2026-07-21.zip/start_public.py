import os
import subprocess
import sys
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
START_FILE = APP_DIR / "start_app.py"


def main() -> int:
    env = os.environ.copy()
    env["HOST"] = "0.0.0.0"
    env["PORT"] = env.get("PORT", "8000")
    return subprocess.call([sys.executable, str(START_FILE)], cwd=str(APP_DIR), env=env)


if __name__ == "__main__":
    raise SystemExit(main())
