from pathlib import Path
import os
import subprocess
import sys


APP_DIR = Path(__file__).resolve().parent
SERVER_FILE = APP_DIR / "server.py"


def main() -> int:
    if not SERVER_FILE.exists():
        print(f"Missing server file: {SERVER_FILE}")
        return 1

    host = os.environ.get("HOST", "127.0.0.1")
    port = os.environ.get("PORT", "8000")

    print("Starting FacilityFlow AI...")
    print(f"Open http://{host}:{port} in your browser")
    env = os.environ.copy()
    return subprocess.call([sys.executable, str(SERVER_FILE)], cwd=str(APP_DIR), env=env)


if __name__ == "__main__":
    raise SystemExit(main())
