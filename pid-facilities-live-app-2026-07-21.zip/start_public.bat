@echo off
setlocal

set "HOST=0.0.0.0"
set "PORT=8000"
call "%~dp0start_app.bat"
