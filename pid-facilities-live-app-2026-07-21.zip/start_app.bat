@echo off
setlocal

set "APP_DIR=%~dp0"
set "PYTHON_EXE=C:\Users\makhuc\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if not exist "%PYTHON_EXE%" (
  echo Bundled Python runtime was not found:
  echo %PYTHON_EXE%
  exit /b 1
)

cd /d "%APP_DIR%"
if "%HOST%"=="" set "HOST=127.0.0.1"
if "%PORT%"=="" set "PORT=8000"
echo Starting FacilityFlow AI...
echo Open http://%HOST%:%PORT% in your browser
"%PYTHON_EXE%" server.py
