import fs from "node:fs/promises";
import path from "node:path";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const [, , stateFile, outputFile] = process.argv;

if (!stateFile || !outputFile) {
  console.error("Usage: node export_bookings.mjs <state.json> <output.xlsx>");
  process.exit(1);
}

const raw = await fs.readFile(stateFile, "utf8");
const state = JSON.parse(raw);
const bookings = state.bookings || [];
const currentYear = new Date().getFullYear();

const byCenter = new Map();
const monthlySummary = new Map();
for (const booking of bookings) {
  const centerName = booking.centerName || "Unknown";
  const current = byCenter.get(centerName) || {
    centerName,
    bookings: 0,
    spacesAvailable: Number(booking.spacesAvailable || 0),
  };
  current.bookings += Number(booking.bookingNumber || 0);
  if (Number(booking.spacesAvailable || 0) > 0) {
    current.spacesAvailable = Number(booking.spacesAvailable || 0);
  }
  current.spacesRemaining = Math.max(current.spacesAvailable - current.bookings, 0);
  byCenter.set(centerName, current);

  const bookingDate = String(booking.bookingDate || "");
  const monthKey = /^\d{4}-\d{2}/.test(bookingDate) ? bookingDate.slice(0, 7) : `${currentYear}-01`;
  const monthlyKey = `${monthKey}__${centerName}`;
  const monthly = monthlySummary.get(monthlyKey) || {
    month: monthKey,
    centerName,
    bookings: 0,
    studentRecords: 0,
    emailRecords: 0,
    spacesAvailable: Number(booking.spacesAvailable || 0),
    spacesRemaining: Number(booking.spacesAvailable || 0),
  };
  monthly.bookings += Number(booking.bookingNumber || 0);
  monthly.studentRecords += booking.studentName ? 1 : 0;
  monthly.emailRecords += booking.email ? 1 : 0;
  if (Number(booking.spacesAvailable || 0) > 0) {
    monthly.spacesAvailable = Number(booking.spacesAvailable || 0);
  }
  monthly.spacesRemaining = Math.max(monthly.spacesAvailable - monthly.bookings, 0);
  monthlySummary.set(monthlyKey, monthly);
}

const uniqueCenters = [...new Set(bookings.map((item) => item.centerName).filter(Boolean))];
const uniqueStudents = [...new Set(bookings.map((item) => item.studentName).filter(Boolean))];
const uniqueEmails = [...new Set(bookings.map((item) => item.email).filter(Boolean))];
const uniqueMonths = [...new Set(bookings.map((item) => String(item.bookingDate || "").slice(0, 7)).filter(Boolean))];
const totalBookings = bookings.reduce((sum, item) => sum + Number(item.bookingNumber || 0), 0);

const workbook = Workbook.create();
const overview = workbook.worksheets.add("Overview");
const summary = workbook.worksheets.add("Summary");
const monthly = workbook.worksheets.add("All Months");
const detail = workbook.worksheets.add("Bookings");

overview.getRange("A1:B6").values = [
  ["Metric", "Value"],
  ["Total Bookings", totalBookings],
  ["Centre Names", uniqueCenters.length],
  ["Student Names", uniqueStudents.length],
  ["Email Records", uniqueEmails.length],
  ["Months Covered", uniqueMonths.length],
];

summary.getRange("A1:D1").values = [["Center Name", "Bookings", "Spaces", "Remaining"]];
summary.getRange(`A2:D${Math.max(2, byCenter.size + 1)}`).values =
  (Array.from(byCenter.values()).map((item) => [
    item.centerName,
    item.bookings,
    item.spacesAvailable,
    item.spacesRemaining,
  ]).length
    ? Array.from(byCenter.values()).map((item) => [
        item.centerName,
        item.bookings,
        item.spacesAvailable,
        item.spacesRemaining,
      ])
    : [["", 0, 0, 0]]);

const monthlyRows = [];
for (let monthIndex = 1; monthIndex <= 12; monthIndex += 1) {
  const monthKey = `${currentYear}-${String(monthIndex).padStart(2, "0")}`;
  (uniqueCenters.length ? uniqueCenters : ["No Center"]).forEach((centerName) => {
    const existing = monthlySummary.get(`${monthKey}__${centerName}`);
    monthlyRows.push(
      existing || {
        month: monthKey,
        centerName,
        bookings: 0,
        studentRecords: 0,
        emailRecords: 0,
        spacesAvailable: 0,
        spacesRemaining: 0,
      }
    );
  });
}

monthly.getRange("A1:G1").values = [[
  "Month",
  "Center Name",
  "Bookings",
  "Student Records",
  "Email Records",
  "Spaces Available",
  "Spaces Remaining",
]];
monthly.getRange(`A2:G${Math.max(2, monthlyRows.length + 1)}`).values =
  (monthlyRows.length
    ? monthlyRows.map((item) => [
        item.month,
        item.centerName,
        item.bookings,
        item.studentRecords,
        item.emailRecords,
        item.spacesAvailable,
        item.spacesRemaining,
      ])
    : [["", "", 0, 0, 0, 0, 0]]);

detail.getRange("A1:G1").values = [[
  "Booking ID",
  "Center Name",
  "Student Name",
  "Email",
  "Booking Number",
  "Spaces Available",
  "Booking Date",
]];
detail.getRange(`A2:G${Math.max(2, bookings.length + 1)}`).values =
  (bookings.map((item) => [
    item.id || "",
    item.centerName || "",
    item.studentName || "",
    item.email || "",
    Number(item.bookingNumber || 0),
    Number(item.spacesAvailable || 0),
    item.bookingDate || "",
  ]).length
    ? bookings.map((item) => [
        item.id || "",
        item.centerName || "",
        item.studentName || "",
        item.email || "",
        Number(item.bookingNumber || 0),
        Number(item.spacesAvailable || 0),
        item.bookingDate || "",
      ])
    : [["", "", "", "", 0, 0, ""]]);

for (const sheet of [overview, summary, monthly, detail]) {
  const used = sheet.getUsedRange();
  used.format.wrapText = true;
  used.format.autofitColumns();
  sheet.freezePanes.freezeRows(1);
  sheet.showGridLines = false;
  const header = sheet.getRange("A1:G1");
  header.format = {
    fill: "#102542",
    font: { bold: true, color: "#FFFFFF" },
    horizontalAlignment: "center",
  };
}

overview.getRange("A1:B1").format = {
  fill: "#102542",
  font: { bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
};

summary.getRange("A1:D1").format = {
  fill: "#102542",
  font: { bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
};

await fs.mkdir(path.dirname(outputFile), { recursive: true });
const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputFile);
