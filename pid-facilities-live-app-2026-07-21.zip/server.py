from __future__ import annotations

import json
import mimetypes
import os
import shutil
import sqlite3
import subprocess
import tempfile
import uuid
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = DATA_DIR / "uploads"
OUTPUTS_DIR = BASE_DIR / "outputs"
STATE_FILE = DATA_DIR / "state.json"
DB_FILE = DATA_DIR / "facilityflow.db"
PID_STATE_FILE = DATA_DIR / "pid_facilities_state.json"

DOCUMENT_KEYS = ["meta", "settings"]
COLLECTION_KEYS = [
    "assets",
    "workOrders",
    "employees",
    "reports",
    "maintenanceChecklist",
    "wip",
    "activity",
    "powerAutomation",
    "automationRuns",
    "studentSupport",
    "bookings",
    "workstations",
]
PID_ADMIN_EMAIL = "makhuc@unisa.ac.za"
PID_ADMIN_USERNAME = "admin.makhuc"
PID_ADMIN_PASSWORD = os.environ.get("PID_ADMIN_PASSWORD", "PID-Admin-2026!")


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def today_date() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def default_pid_state() -> dict:
    centre_id = "CTR-0001"
    second_centre_id = "CTR-0002"
    admin_id = "USR-0001"
    intern_id = "USR-0004"
    return {
        "orgName": "PID Facilities",
        "msEmail": PID_ADMIN_EMAIL,
        "waNumber": "+27 63 411 6900",
        "requireMsAuthForAdmin": False,
        "liveMode": True,
        "centres": [
            {
                "id": centre_id,
                "name": "Pretoria HQ",
                "address": "Church Street, Pretoria Central",
                "lat": -25.7479,
                "lng": 28.2293,
                "manager": "S. Botha",
            },
            {
                "id": second_centre_id,
                "name": "Centurion Branch",
                "address": "Centurion Mall Precinct, Centurion",
                "lat": -25.8601,
                "lng": 28.1894,
                "manager": "T. Nkosi",
            },
        ],
        "users": [
            {
                "id": admin_id,
                "name": "Admin (M. Khuc)",
                "role": "admin",
                "centreId": centre_id,
                "email": PID_ADMIN_EMAIL,
                "phone": "+27 63 411 6900",
                "username": PID_ADMIN_USERNAME,
                "password": PID_ADMIN_PASSWORD,
            },
            {
                "id": "USR-0002",
                "name": "S. Botha",
                "role": "centre",
                "centreId": centre_id,
                "email": "s.botha@company.co.za",
                "phone": "+27 82 111 2222",
            },
            {
                "id": "USR-0003",
                "name": "T. Nkosi",
                "role": "technician",
                "centreId": second_centre_id,
                "email": "t.nkosi@company.co.za",
                "phone": "+27 83 222 3333",
            },
            {
                "id": intern_id,
                "name": "L. Dube",
                "role": "intern",
                "centreId": centre_id,
                "email": "l.dube@company.co.za",
                "phone": "+27 84 333 4444",
            },
        ],
        "assets": [
            {
                "id": "AST-0001",
                "name": "Rooftop AHU 1",
                "category": "HVAC",
                "location": "Roof",
                "centreId": centre_id,
                "status": "operational",
                "purchaseDate": "2021-03-10",
                "value": 185000,
            },
            {
                "id": "AST-0002",
                "name": "Backup Generator",
                "category": "Electrical",
                "location": "Basement",
                "centreId": centre_id,
                "status": "maintenance",
                "purchaseDate": "2019-11-02",
                "value": 420000,
            },
            {
                "id": "AST-0003",
                "name": "Fire Pump Set",
                "category": "Fire Safety",
                "location": "Plant Room",
                "centreId": second_centre_id,
                "status": "operational",
                "purchaseDate": "2020-06-18",
                "value": 96000,
            },
            {
                "id": "AST-0004",
                "name": "Lift 2",
                "category": "Vertical Transport",
                "location": "Core",
                "centreId": second_centre_id,
                "status": "down",
                "purchaseDate": "2018-01-25",
                "value": 610000,
            },
        ],
        "workOrders": [
            {
                "id": "WO-0001",
                "title": "Lift 2 motor fault",
                "assetId": "AST-0004",
                "centreId": second_centre_id,
                "type": "corrective",
                "priority": "critical",
                "status": "in_progress",
                "assignedUserId": "USR-0003",
                "assignedTo": "T. Nkosi",
                "waNumber": "+27 83 222 3333",
                "location": "Core",
                "createdDate": today_date(),
                "dueDate": today_date(),
                "description": "Lift stopped between floors, motor overheating.",
                "gpsCheckin": None,
            },
            {
                "id": "WO-0002",
                "title": "Generator load test",
                "assetId": "AST-0002",
                "centreId": centre_id,
                "type": "preventive",
                "priority": "medium",
                "status": "open",
                "assignedUserId": "USR-0002",
                "assignedTo": "S. Botha",
                "waNumber": "+27 82 111 2222",
                "location": "Basement",
                "createdDate": today_date(),
                "dueDate": today_date(),
                "description": "Quarterly load bank test.",
                "gpsCheckin": None,
            },
        ],
        "pmTasks": [
            {
                "id": "PM-0001",
                "assetId": "AST-0003",
                "task": "Fire pump weekly run test",
                "frequency": "Weekly",
                "lastDone": today_date(),
                "nextDue": today_date(),
                "assignedTo": "S. Botha",
            }
        ],
        "projects": [],
        "incidents": [],
        "inspections": [],
        "assetReports": [],
        "doodleLinks": [],
        "automationRuns": [],
        "internChecklists": {
            intern_id: [
                {"id": "ic1", "text": "Site safety induction completed", "done": True},
                {"id": "ic2", "text": "Issued PPE (helmet, boots, hi-vis)", "done": True},
                {"id": "ic3", "text": "Introduced to centre manager and team", "done": False},
            ]
        },
        "seq": {
            "asset": 4,
            "wo": 2,
            "pm": 1,
            "proj": 0,
            "inc": 0,
            "insp": 0,
            "centre": 2,
            "user": 4,
            "ar": 0,
            "dl": 0,
            "auto": 0,
        },
    }


def sanitize_pid_state(state: dict) -> dict:
    defaults = default_pid_state()
    if not isinstance(state, dict):
        state = {}
    sanitized = dict(state)
    for key, value in defaults.items():
        if key not in sanitized:
            sanitized[key] = value if not isinstance(value, (dict, list)) else json.loads(json.dumps(value))
    for key in [
        "centres",
        "users",
        "assets",
        "workOrders",
        "pmTasks",
        "projects",
        "incidents",
        "inspections",
        "assetReports",
        "doodleLinks",
        "automationRuns",
    ]:
        if not isinstance(sanitized.get(key), list):
            sanitized[key] = []
    if not isinstance(sanitized.get("internChecklists"), dict):
        sanitized["internChecklists"] = {}
    if not isinstance(sanitized.get("seq"), dict):
        sanitized["seq"] = {}
    for key, value in defaults["seq"].items():
        sanitized["seq"].setdefault(key, value)
    sanitized["liveMode"] = True
    ensure_pid_admin_credentials(sanitized)
    return sanitized


def ensure_pid_admin_credentials(state: dict) -> None:
    users = state.setdefault("users", [])
    admin = next((user for user in users if str(user.get("email", "")).lower() == PID_ADMIN_EMAIL), None)
    if admin is None:
        state.setdefault("seq", {})["user"] = max(int(state.get("seq", {}).get("user", 0) or 0), len(users)) + 1
        admin = {
            "id": f"USR-{int(state['seq']['user']):04d}",
            "name": "Admin (M. Khuc)",
            "role": "admin",
            "centreId": state.get("centres", [{}])[0].get("id", "") if state.get("centres") else "",
            "email": PID_ADMIN_EMAIL,
            "phone": "+27 63 411 6900",
        }
        users.insert(0, admin)
    admin["role"] = "admin"
    admin.setdefault("name", "Admin (M. Khuc)")
    admin.setdefault("phone", "+27 63 411 6900")
    admin["username"] = admin.get("username") or PID_ADMIN_USERNAME
    admin["password"] = admin.get("password") or PID_ADMIN_PASSWORD


def load_pid_state() -> dict:
    ensure_storage()
    if PID_STATE_FILE.exists():
        state = json.loads(PID_STATE_FILE.read_text(encoding="utf-8"))
    else:
        state = default_pid_state()
    state = sanitize_pid_state(state)
    save_pid_state(state)
    return state


def save_pid_state(state: dict) -> dict:
    ensure_storage()
    sanitized = sanitize_pid_state(state)
    PID_STATE_FILE.write_text(json.dumps(sanitized, indent=2), encoding="utf-8")
    return sanitized


def run_pid_automation_cycle(state: dict) -> dict:
    today = datetime.now().date()
    open_statuses = {"open", "in_progress", "pending_approval", "on_hold"}
    overdue = []
    high_priority = []
    unassigned = []
    for order in state.get("workOrders", []):
        status = str(order.get("status", "")).lower()
        if status not in open_statuses:
            continue
        if str(order.get("priority", "")).lower() in {"high", "critical"}:
            high_priority.append(order.get("id", ""))
        if not order.get("assignedTo") or order.get("assignedTo") == "Unassigned":
            unassigned.append(order.get("id", ""))
        due_text = order.get("dueDate")
        if due_text:
            try:
                due_date = datetime.strptime(due_text, "%Y-%m-%d").date()
                if due_date < today:
                    overdue.append(order.get("id", ""))
            except ValueError:
                pass

    state.setdefault("seq", {})["auto"] = int(state.get("seq", {}).get("auto", 0) or 0) + 1
    cycle = {
        "id": f"AUTO-{int(state['seq']['auto']):04d}",
        "processedAt": now_iso(),
        "overdueWorkOrders": overdue,
        "highPriorityWorkOrders": high_priority,
        "unassignedWorkOrders": unassigned,
        "message": (
            f"Live automation scanned {len(state.get('assets', []))} assets, "
            f"{len(state.get('workOrders', []))} work orders, and "
            f"{len(state.get('incidents', []))} safety records."
        ),
    }
    state.setdefault("automationRuns", []).insert(0, cycle)
    state["automationRuns"] = state["automationRuns"][:25]
    return cycle


def default_state() -> dict:
    assets = [
        {
            "id": "AST-1001",
            "name": "Main Water Pump",
            "category": "Mechanical",
            "location": "Plant Room A",
            "status": "Functional",
            "condition": "Good",
            "owner": "Employer",
            "notes": "Quarterly service complete.",
            "updatedAt": now_iso(),
        },
        {
            "id": "AST-1002",
            "name": "Office AC Unit",
            "category": "HVAC",
            "location": "Admin Block",
            "status": "Damaged",
            "condition": "Needs repair",
            "owner": "Employer",
            "notes": "Cooling failure reported by staff.",
            "updatedAt": now_iso(),
        },
        {
            "id": "AST-1003",
            "name": "Security Camera C7",
            "category": "Security",
            "location": "Warehouse Gate",
            "status": "WIP",
            "condition": "Under inspection",
            "owner": "Employer",
            "notes": "Awaiting replacement bracket.",
            "updatedAt": now_iso(),
        },
    ]
    work_orders = [
        {
            "id": "WO-5001",
            "title": "Repair AC Unit",
            "assetId": "AST-1002",
            "priority": "High",
            "assignedTo": "Sipho Dlamini",
            "department": "Maintenance",
            "status": "In Progress",
            "dueDate": datetime.now().strftime("%Y-%m-%d"),
            "description": "Inspect compressor and replace failed parts.",
            "updatedAt": now_iso(),
        },
        {
            "id": "WO-5002",
            "title": "Inspect Camera Bracket",
            "assetId": "AST-1003",
            "priority": "Medium",
            "assignedTo": "Lebo Molefe",
            "department": "Security Systems",
            "status": "Pending",
            "dueDate": datetime.now().strftime("%Y-%m-%d"),
            "description": "Confirm part number and installation slot.",
            "updatedAt": now_iso(),
        },
    ]
    employees = [
        {
            "id": "EMP-01",
            "name": "Nomsa Khumalo",
            "role": "Employer Admin",
            "portal": "Employer",
            "email": "nomsa@example.com",
            "team": "Management",
        },
        {
            "id": "EMP-02",
            "name": "Sipho Dlamini",
            "role": "Technician",
            "portal": "Employee",
            "email": "sipho@example.com",
            "team": "Maintenance",
        },
        {
            "id": "EMP-03",
            "name": "Lebo Molefe",
            "role": "Inspector",
            "portal": "Employee",
            "email": "lebo@example.com",
            "team": "Security Systems",
        },
    ]
    reports = [
        {
            "id": "REP-9001",
            "title": "Weekly Maintenance Review",
            "category": "Maintenance",
            "uploadedBy": "Nomsa Khumalo",
            "fileName": "weekly-maintenance-summary.pdf",
            "notes": "Shared with leadership.",
            "uploadedAt": now_iso(),
        }
    ]
    return {
        "meta": {
            "createdAt": now_iso(),
            "appName": "FacilityFlow AI",
            "version": "2.0.0",
            "databaseEngine": "SQLite",
            "databaseFile": DB_FILE.name,
        },
        "settings": {
            "companyName": "Smart Facilities Group",
            "employerCanEdit": True,
            "aiMode": "Local Intelligence",
            "autoRefreshSeconds": 5,
            "automationMode": "Seconds Automation",
            "doodleLink": "https://doodle.com/",
            "doodleSSOLink": "https://doodle.com/login/sso",
            "outlookLink": "https://outlook.office.com/mail/",
            "teamsLink": "https://teams.microsoft.com/",
            "powerAutomateLink": "https://make.powerautomate.com/",
            "powerBILink": "https://app.powerbi.com/",
            "whatsAppLink": "https://wa.me/",
            "telegramLink": "https://t.me/",
            "gpsSiteName": "Johannesburg Operations Hub",
            "gpsLat": -26.2041,
            "gpsLng": 28.0473,
            "studentSupportEmail": "studentsupport@unisa.ac.za",
            "studentSupportPhone": "0800 00 1870",
            "accessibilityStandard": "WCAG 2.2 AA",
        },
        "assets": assets,
        "workOrders": work_orders,
        "employees": employees,
        "reports": reports,
        "maintenanceChecklist": [
            {"id": "MC-1", "item": "Fire extinguishers inspection", "status": "Complete"},
            {"id": "MC-2", "item": "Elevator safety check", "status": "WIP"},
            {"id": "MC-3", "item": "Backup generator test", "status": "Pending"},
        ],
        "wip": [
            {"id": "WIP-1", "title": "Roof leak repair", "status": "Awaiting contractor"},
            {"id": "WIP-2", "title": "LED replacement phase 2", "status": "On schedule"},
        ],
        "activity": [
            {"id": "ACT-1", "message": "AC repair assigned to Sipho Dlamini.", "timestamp": now_iso()},
            {"id": "ACT-2", "message": "Security camera inspection queued.", "timestamp": now_iso()},
        ],
        "powerAutomation": [
            {
                "id": "PA-1",
                "name": "Damaged Asset Alert Flow",
                "trigger": "New damaged asset captured",
                "action": "Notify Teams, Outlook, and log activity",
                "status": "Ready",
            },
            {
                "id": "PA-2",
                "name": "Work Order Escalation Flow",
                "trigger": "High priority job overdue",
                "action": "Escalate to employer and maintenance lead",
                "status": "Ready",
            },
            {
                "id": "PA-3",
                "name": "Report Control Flow",
                "trigger": "New report uploaded",
                "action": "Record evidence and share governance update",
                "status": "Ready",
            },
        ],
        "automationRuns": [],
        "studentSupport": [
            {
                "id": "SS-1",
                "title": "Academic Support",
                "channel": "Online, email, workshops",
                "detail": "Study skills, time management, exam preparation, and academic adjustment support.",
            },
            {
                "id": "SS-2",
                "title": "Career Guidance",
                "channel": "Counsellor sessions",
                "detail": "Qualification choice, employability preparation, and career planning support.",
            },
            {
                "id": "SS-3",
                "title": "Personal Wellness",
                "channel": "Confidential support",
                "detail": "Personal and emotional support for challenges affecting study success.",
            },
            {
                "id": "SS-4",
                "title": "Disability & Accessibility",
                "channel": "Reasonable accommodation",
                "detail": "Accessible support pathways and accommodation-aware service routing.",
            },
        ],
        "bookings": [
            {
                "id": "BK-1001",
                "centerName": "Florida Campus Lab",
                "studentName": "Aphiwe Nkosi",
                "email": "aphiwe.nkosi@unisa.ac.za",
                "bookingNumber": 1,
                "spacesAvailable": 30,
                "bookingDate": datetime.now().strftime("%Y-%m-%d"),
                "source": "Doodle",
            },
            {
                "id": "BK-1002",
                "centerName": "Johannesburg Learning Centre",
                "studentName": "Karabo Mokoena",
                "email": "karabo.mokoena@unisa.ac.za",
                "bookingNumber": 1,
                "spacesAvailable": 24,
                "bookingDate": datetime.now().strftime("%Y-%m-%d"),
                "source": "Doodle",
            },
            {
                "id": "BK-1003",
                "centerName": "Florida Campus Lab",
                "studentName": "Lerato Mthembu",
                "email": "lerato.mthembu@unisa.ac.za",
                "bookingNumber": 1,
                "spacesAvailable": 30,
                "bookingDate": datetime.now().strftime("%Y-%m-%d"),
                "source": "Doodle",
            },
        ],
        "workstations": [
            {
                "id": "WS-101",
                "name": "Computer Lab A - Station 01",
                "location": "Main Library",
                "status": "Available",
                "internet": "Connected",
                "accessibility": "Screen reader ready",
            },
            {
                "id": "WS-102",
                "name": "Computer Lab A - Station 02",
                "location": "Main Library",
                "status": "Occupied",
                "internet": "Connected",
                "accessibility": "Standard",
            },
            {
                "id": "WS-201",
                "name": "Student Support Hub - Station 01",
                "location": "Student Centre",
                "status": "Maintenance",
                "internet": "Pending check",
                "accessibility": "Height adjustable desk",
            },
        ],
    }


def get_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_FILE)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_db(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS documents (
            name TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS records (
            collection TEXT NOT NULL,
            record_key TEXT NOT NULL,
            sort_order INTEGER NOT NULL,
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (collection, record_key)
        )
        """
    )
    connection.commit()


def sanitize_state(state: dict) -> dict:
    defaults = default_state()
    sanitized = {
        "meta": dict(state.get("meta") or {}),
        "settings": dict(state.get("settings") or {}),
    }

    for key, value in defaults["meta"].items():
        sanitized["meta"].setdefault(key, value)
    sanitized["meta"]["databaseEngine"] = "SQLite"
    sanitized["meta"]["databaseFile"] = DB_FILE.name

    for key, value in defaults["settings"].items():
        sanitized["settings"].setdefault(key, value)

    for key in COLLECTION_KEYS:
        items = state.get(key, defaults.get(key, []))
        sanitized[key] = list(items if isinstance(items, list) else defaults.get(key, []))

    sanitized.pop("users", None)
    for key in ["authMode", "allowedEmailDomain", "microsoftLoginLink"]:
        sanitized["settings"].pop(key, None)

    return sanitized


def write_state_to_db(connection: sqlite3.Connection, state: dict) -> None:
    timestamp = now_iso()
    sanitized = sanitize_state(state)

    with connection:
        for key in DOCUMENT_KEYS:
            connection.execute(
                """
                INSERT INTO documents (name, payload, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    payload = excluded.payload,
                    updated_at = excluded.updated_at
                """,
                (key, json.dumps(sanitized[key]), timestamp),
            )

        for collection in COLLECTION_KEYS:
            connection.execute("DELETE FROM records WHERE collection = ?", (collection,))
            for index, item in enumerate(sanitized[collection]):
                record_key = str(item.get("id") or f"{collection}-{index}")
                connection.execute(
                    """
                    INSERT INTO records (collection, record_key, sort_order, payload, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (collection, record_key, index, json.dumps(item), timestamp),
                )


def read_state_from_db(connection: sqlite3.Connection) -> dict:
    state: dict = {}

    for key in DOCUMENT_KEYS:
        row = connection.execute("SELECT payload FROM documents WHERE name = ?", (key,)).fetchone()
        state[key] = json.loads(row["payload"]) if row else {}

    for collection in COLLECTION_KEYS:
        rows = connection.execute(
            "SELECT payload FROM records WHERE collection = ? ORDER BY sort_order ASC",
            (collection,),
        ).fetchall()
        state[collection] = [json.loads(row["payload"]) for row in rows]

    return sanitize_state(state)


def ensure_storage() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    UPLOADS_DIR.mkdir(exist_ok=True)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    seed_state = None
    if STATE_FILE.exists():
        seed_state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    else:
        STATE_FILE.write_text(json.dumps(default_state(), indent=2), encoding="utf-8")
        seed_state = default_state()

    with get_connection() as connection:
        initialize_db(connection)
        has_meta = connection.execute("SELECT 1 FROM documents WHERE name = 'meta'").fetchone()
        if not has_meta:
            write_state_to_db(connection, seed_state)


def load_state() -> dict:
    ensure_storage()
    with get_connection() as connection:
        return read_state_from_db(connection)


def save_state(state: dict) -> None:
    ensure_storage()
    sanitized = sanitize_state(state)
    with get_connection() as connection:
        write_state_to_db(connection, sanitized)
    STATE_FILE.write_text(json.dumps(sanitized, indent=2), encoding="utf-8")


def summarize_ai(state: dict) -> dict:
    assets = state["assets"]
    work_orders = state["workOrders"]
    damaged = [a for a in assets if a["status"].lower() == "damaged"]
    wip_assets = [a for a in assets if a["status"].lower() == "wip"]
    open_orders = [w for w in work_orders if w["status"].lower() not in {"completed", "closed"}]
    top_priority = sorted(work_orders, key=lambda item: {"High": 0, "Medium": 1, "Low": 2}.get(item["priority"], 3))

    summary_lines = [
        f"{len(assets)} total assets tracked.",
        f"{len(damaged)} damaged assets need attention.",
        f"{len(wip_assets)} assets currently marked as work in progress.",
        f"{len(open_orders)} open work orders are active.",
    ]
    alerts = []
    if damaged:
        alerts.append(f"Urgent focus: {damaged[0]['name']} at {damaged[0]['location']} is still damaged.")
    if top_priority:
        alerts.append(f"Top work allocation: {top_priority[0]['title']} assigned to {top_priority[0]['assignedTo']}.")
    if not alerts:
        alerts.append("No critical alerts detected right now.")

    recommendations = [
        "Prioritize damaged assets before opening new low-priority work.",
        "Use the search engine to locate asset history by ID, location, or assignee.",
        "Use the new SQLite database layer to keep records stable as the app grows.",
    ]
    return {
        "summary": " ".join(summary_lines),
        "alerts": alerts,
        "recommendations": recommendations,
    }


def power_bi_payload(state: dict) -> dict:
    center_summary = {}
    monthly_summary = {}
    for booking in state.get("bookings", []):
        center = booking.get("centerName", "Unknown")
        summary = center_summary.setdefault(
            center,
            {
                "centerName": center,
                "bookings": 0,
                "spacesAvailable": int(booking.get("spacesAvailable", 0) or 0),
            },
        )
        summary["bookings"] += int(booking.get("bookingNumber", 0) or 0)
        if int(booking.get("spacesAvailable", 0) or 0) > 0:
            summary["spacesAvailable"] = int(booking.get("spacesAvailable", 0) or 0)
        summary["spacesRemaining"] = max(summary["spacesAvailable"] - summary["bookings"], 0)

        booking_date = str(booking.get("bookingDate", ""))
        month_key = booking_date[:7] if len(booking_date) >= 7 else "Unknown"
        monthly_key = f"{month_key}__{center}"
        monthly = monthly_summary.setdefault(
            monthly_key,
            {
                "month": month_key,
                "centerName": center,
                "bookings": 0,
                "studentRecords": 0,
                "emailRecords": 0,
                "spacesAvailable": int(booking.get("spacesAvailable", 0) or 0),
            },
        )
        monthly["bookings"] += int(booking.get("bookingNumber", 0) or 0)
        monthly["studentRecords"] += 1 if booking.get("studentName") else 0
        monthly["emailRecords"] += 1 if booking.get("email") else 0
        if int(booking.get("spacesAvailable", 0) or 0) > 0:
            monthly["spacesAvailable"] = int(booking.get("spacesAvailable", 0) or 0)
        monthly["spacesRemaining"] = max(monthly["spacesAvailable"] - monthly["bookings"], 0)

    records = {key: state.get(key, []) for key in COLLECTION_KEYS}
    counts = {key: len(value) for key, value in records.items()}
    return {
        "generatedAt": now_iso(),
        "databaseEngine": state.get("meta", {}).get("databaseEngine", "SQLite"),
        "counts": counts,
        "records": records,
        "bookingCapacity": list(center_summary.values()),
        "monthlyBookingSummary": list(monthly_summary.values()),
    }


def run_automation_cycle(state: dict) -> dict:
    counts = {
        "assets": len(state.get("assets", [])),
        "workOrders": len(state.get("workOrders", [])),
        "reports": len(state.get("reports", [])),
        "bookings": len(state.get("bookings", [])),
    }
    cycle = {
        "id": f"AUTO-{uuid.uuid4().hex[:6].upper()}",
        "processedAt": now_iso(),
        "processed": counts,
        "message": f"Automation cycle processed {sum(counts.values())} records across assets, work orders, reports, and bookings.",
    }
    state.setdefault("automationRuns", []).insert(0, cycle)
    state["automationRuns"] = state["automationRuns"][:20]
    return cycle


def export_bookings_workbook(state: dict) -> Path:
    node_exe = Path(r"C:\Users\makhuc\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe")
    script_path = BASE_DIR / "scripts" / "export_bookings.mjs"
    output_path = OUTPUTS_DIR / "doodle-bookings-export.xlsx"
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".json", dir=DATA_DIR)
    temp_path = Path(temp_file.name)
    temp_file.close()
    try:
        temp_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
        subprocess.run(
            [str(node_exe), str(script_path), str(temp_path), str(output_path)],
            check=True,
            cwd=str(BASE_DIR),
        )
    finally:
        temp_path.unlink(missing_ok=True)
    return output_path


def normalize_records(records: list[dict]) -> list[dict]:
    normalized = []
    for row in records:
        clean = {}
        for key, value in row.items():
            text_key = str(key).strip() or "field"
            if pd.isna(value):
                clean[text_key] = ""
            else:
                clean[text_key] = str(value).strip()
        normalized.append(clean)
    return normalized


class AppHandler(BaseHTTPRequestHandler):
    server_version = "FacilityFlowAI/2.0"

    def _send_json(self, payload: dict | list, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path) -> None:
        if not path.exists() or not path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return
        content_type, _ = mimetypes.guess_type(str(path))
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8") or "{}")

    def _append_activity(self, state: dict, message: str) -> None:
        state.setdefault("activity", []).insert(
            0,
            {"id": f"ACT-{uuid.uuid4().hex[:8]}", "message": message, "timestamp": now_iso()},
        )

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/state":
            state = load_state()
            payload = dict(state)
            payload["ai"] = summarize_ai(state)
            self._send_json(payload)
            return

        if path == "/api/powerbi-records":
            state = load_state()
            self._send_json(power_bi_payload(state))
            return

        if path == "/api/database-status":
            state = load_state()
            self._send_json(
                {
                    "ok": True,
                    "databaseEngine": state["meta"].get("databaseEngine", "SQLite"),
                    "databaseFile": str(DB_FILE),
                    "collections": {key: len(state.get(key, [])) for key in COLLECTION_KEYS},
                }
            )
            return

        if path == "/api/pid/state":
            self._send_json(load_pid_state())
            return

        if path == "/api/export-doodle-bookings":
            try:
                export_path = export_bookings_workbook(load_state())
                self._send_file(export_path)
            except Exception as exc:
                self._send_json({"ok": False, "error": f"Workbook export failed: {exc}"}, status=500)
            return

        if path.startswith("/uploads/"):
            safe_name = Path(path.replace("/uploads/", "", 1)).name
            self._send_file(UPLOADS_DIR / safe_name)
            return

        relative = "index.html" if path == "/" else path.lstrip("/")
        target = STATIC_DIR / relative
        if target.exists():
            self._send_file(target)
            return
        self.send_error(HTTPStatus.NOT_FOUND, "Route not found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)

        if parsed.path == "/api/assets":
            state = load_state()
            payload = self._read_json_body()
            asset = {
                "id": payload.get("id") or f"AST-{uuid.uuid4().hex[:6].upper()}",
                "name": payload.get("name", "").strip(),
                "category": payload.get("category", "").strip(),
                "location": payload.get("location", "").strip(),
                "status": payload.get("status", "Functional").strip(),
                "condition": payload.get("condition", "").strip(),
                "owner": payload.get("owner", "Employer").strip(),
                "notes": payload.get("notes", "").strip(),
                "updatedAt": now_iso(),
            }
            state["assets"].insert(0, asset)
            self._append_activity(state, f"Asset {asset['id']} captured: {asset['name']}.")
            save_state(state)
            self._send_json({"ok": True, "asset": asset, "databaseEngine": "SQLite"})
            return

        if parsed.path == "/api/workorders":
            state = load_state()
            payload = self._read_json_body()
            work_order = {
                "id": payload.get("id") or f"WO-{uuid.uuid4().hex[:6].upper()}",
                "title": payload.get("title", "").strip(),
                "assetId": payload.get("assetId", "").strip(),
                "priority": payload.get("priority", "Medium").strip(),
                "assignedTo": payload.get("assignedTo", "").strip(),
                "department": payload.get("department", "").strip(),
                "status": payload.get("status", "Pending").strip(),
                "dueDate": payload.get("dueDate", "").strip(),
                "description": payload.get("description", "").strip(),
                "updatedAt": now_iso(),
            }
            state["workOrders"].insert(0, work_order)
            self._append_activity(state, f"Work order {work_order['id']} created for {work_order['title']}.")
            save_state(state)
            self._send_json({"ok": True, "workOrder": work_order, "databaseEngine": "SQLite"})
            return

        if parsed.path == "/api/reports":
            state = load_state()
            payload = self._read_json_body()
            report = {
                "id": payload.get("id") or f"REP-{uuid.uuid4().hex[:6].upper()}",
                "title": payload.get("title", "").strip(),
                "category": payload.get("category", "General").strip(),
                "uploadedBy": payload.get("uploadedBy", "Employer").strip(),
                "fileName": payload.get("fileName", "").strip(),
                "notes": payload.get("notes", "").strip(),
                "uploadedAt": now_iso(),
            }
            state["reports"].insert(0, report)
            self._append_activity(state, f"Report uploaded: {report['title']}.")
            save_state(state)
            self._send_json({"ok": True, "report": report, "databaseEngine": "SQLite"})
            return

        if parsed.path == "/api/settings":
            state = load_state()
            payload = self._read_json_body()
            settings = state.setdefault("settings", {})
            blocked_keys = {"authMode", "allowedEmailDomain", "microsoftLoginLink"}
            for key, value in payload.items():
                if key in blocked_keys:
                    continue
                if key == "employerCanEdit":
                    settings[key] = bool(value)
                elif key in {"gpsLat", "gpsLng"}:
                    try:
                        settings[key] = float(value)
                    except (TypeError, ValueError):
                        settings[key] = settings.get(key)
                elif key == "autoRefreshSeconds":
                    try:
                        settings[key] = max(2, int(value))
                    except (TypeError, ValueError):
                        settings[key] = settings.get(key, 5)
                else:
                    settings[key] = str(value).strip()
            self._append_activity(state, "Application settings updated.")
            save_state(state)
            self._send_json({"ok": True, "settings": settings, "databaseEngine": "SQLite"})
            return

        if parsed.path == "/api/automation-run":
            state = load_state()
            cycle = run_automation_cycle(state)
            self._append_activity(state, cycle["message"])
            save_state(state)
            self._send_json({"ok": True, "cycle": cycle, "automationRuns": state.get("automationRuns", [])})
            return

        if parsed.path == "/api/pid/state":
            payload = self._read_json_body()
            saved = save_pid_state(payload)
            self._send_json({"ok": True, "state": saved})
            return

        if parsed.path == "/api/pid/automation-run":
            state = load_pid_state()
            cycle = run_pid_automation_cycle(state)
            saved = save_pid_state(state)
            self._send_json({"ok": True, "cycle": cycle, "state": saved})
            return

        if parsed.path == "/api/upload-assets":
            query = parse_qs(parsed.query)
            file_name = query.get("filename", ["assets-upload.xlsx"])[0]
            extension = Path(file_name).suffix.lower()
            length = int(self.headers.get("Content-Length", "0"))
            file_bytes = self.rfile.read(length) if length else b""
            if not file_bytes:
                self._send_json({"ok": False, "error": "No file uploaded."}, status=400)
                return

            temp_name = f"{uuid.uuid4().hex}{extension or '.bin'}"
            temp_path = UPLOADS_DIR / temp_name
            temp_path.write_bytes(file_bytes)
            try:
                if extension == ".csv":
                    df = pd.read_csv(temp_path)
                else:
                    df = pd.read_excel(temp_path)
                rows = normalize_records(df.to_dict(orient="records"))
                state = load_state()
                imported = []
                for row in rows:
                    imported.append(
                        {
                            "id": row.get("id") or row.get("ID") or f"AST-{uuid.uuid4().hex[:6].upper()}",
                            "name": row.get("name") or row.get("Asset Name") or "Imported Asset",
                            "category": row.get("category") or row.get("Category") or "General",
                            "location": row.get("location") or row.get("Location") or "Unknown",
                            "status": row.get("status") or row.get("Status") or "Functional",
                            "condition": row.get("condition") or row.get("Condition") or "Imported",
                            "owner": row.get("owner") or row.get("Owner") or "Employer",
                            "notes": row.get("notes") or row.get("Notes") or "Imported from spreadsheet",
                            "updatedAt": now_iso(),
                        }
                    )
                state["assets"] = imported + state["assets"]
                final_name = f"{datetime.now().strftime('%Y%m%d-%H%M%S')}-{Path(file_name).name}"
                final_path = UPLOADS_DIR / final_name
                shutil.move(str(temp_path), str(final_path))
                self._append_activity(state, f"Imported {len(imported)} assets from {file_name}.")
                save_state(state)
                self._send_json({"ok": True, "count": len(imported), "fileName": final_name, "databaseEngine": "SQLite"})
            except Exception as exc:
                if temp_path.exists():
                    temp_path.unlink()
                self._send_json({"ok": False, "error": f"Upload failed: {exc}"}, status=400)
            return

        self._send_json({"ok": False, "error": "Unknown endpoint"}, status=404)


def run() -> None:
    ensure_storage()
    port = int(os.environ.get("PORT", "8000"))
    host = os.environ.get("HOST", "0.0.0.0")
    server = ThreadingHTTPServer((host, port), AppHandler)
    print(f"FacilityFlow AI running at http://{host}:{port}")
    print(f"SQLite database ready at {DB_FILE}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    finally:
        server.server_close()


if __name__ == "__main__":
    run()
