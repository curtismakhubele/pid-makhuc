# FacilityFlow AI

FacilityFlow AI is a lightweight facilities management web app that runs locally with Python. It includes:

- Asset management with all / functional / damaged / WIP views
- Excel and CSV asset list upload
- Work allocation and maintenance tracking
- Employer and employee portal sections
- Report logging and control
- Search across operational records
- Local AI insight panel for summaries, alerts, and recommendations
- Outlook and Teams quick links

## Run

Simplest option:

```powershell
.\start_app.bat
```

Network option for phones and laptops on the same Wi-Fi/LAN:

```powershell
.\start_public.bat
```

Python launcher:

```powershell
& "C:\Users\makhuc\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" .\start_app.py
```

Direct command:

```powershell
& "C:\Users\makhuc\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" .\server.py
```

Then open:

```text
http://127.0.0.1:8000
```

Advanced PID workspace:

```text
http://127.0.0.1:8000/pid-facilities.html
```
